#! /bin/sh

./Markdown.pl manual.text > manual.html
