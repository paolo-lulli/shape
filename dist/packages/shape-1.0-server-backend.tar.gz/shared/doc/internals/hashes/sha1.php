<?

echo sha1('provadicheche');
echo "\n"

?>
