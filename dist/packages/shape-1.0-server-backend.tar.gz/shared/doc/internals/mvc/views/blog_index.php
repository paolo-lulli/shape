<h1><?php echo $blog_heading; ?></h1>
