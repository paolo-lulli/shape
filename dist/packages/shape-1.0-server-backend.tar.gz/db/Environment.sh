#! /bin/sh

#
# Per la configurazione di un ambiente iniziale
# (preferibile sostituire path ASSOLUTI e non relativi)
#


# Variabili per Le utenze di DB

DB_INSTANCE="hbf_03";
DB_USER="hbf_03";
DB_PASS="hbf_03"


export DB_INSTANCE DB_USER DB_PASS
