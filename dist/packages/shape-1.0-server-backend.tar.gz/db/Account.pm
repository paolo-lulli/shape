#! /usr/bin/perl

use DBI;
use strict;

use lib qw(../lib);
use dbiclient;

use lib qw(../conf);
use configuration;


 
my $create_Account_query= " create table Account(  
	ID char(36)
	, created date
	, ID_User varchar(36)
	, active int
	, updated date
	, ID_Role varchar(36)
	, ID_Usergroup varchar(36)  );";
sub create_Account(){
       	&launch_query($create_Account_query);
}
 

sub save_Account($$$$$$){


my $ID = $_[0];
my $created = $_[1];
my $ID_User = $_[2];
my $active = $_[3];
my $updated = $_[4];
my $ID_Role = $_[5];
my $ID_Usergroup = $_[6];
my $sql = "insert into Account values ( '$ID', '$created', '$ID_User', '$active', '$updated', '$ID_Role', '$ID_Usergroup' )";

&launch_query($sql);

}


 
sub update_Account_equals($$$){

my $tableName = $_[0];
my $rKeyValuePairs = $_[1];
my $rWhere = $_[2];

my %wherea = %{$rWhere};
my %keyValuePairs = %{$rKeyValuePairs};

my $updatefields_set = " SET ";
my $updatefields_where = " WHERE ";
my $field;

my $keyssize = keys( %keyValuePairs );
my $wheresize = keys( %wherea );

my $fieldcount = 0;
foreach $field (keys(%keyValuePairs)){
	$fieldcount++; 
	print "field ---- $field
";
	print "SIZE:  $keyssize
";
	$updatefields_set.= "$field = '$keyValuePairs{\"$field\"}'";
	print "SET -------------->  $updatefields_set\n";
	if (  $fieldcount <=  $keyssize -1 ){
		$updatefields_set.= " , ";
	}
}

$fieldcount = 0;
foreach $field (keys(%wherea)){
	$fieldcount++; 
	$updatefields_where .= "$field =  '$wherea{\"$field\"}'" ;
	print "WHERE ----------->  $updatefields_where
";
}

my $sql = "update $tableName $updatefields_set  $updatefields_where ";

&launch_query($sql);
}





1; 