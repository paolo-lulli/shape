<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Policy.inc');
include('header.inc');
//

include('form_Policy.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Policy.inc');
include('header.inc');
//

include('form_Policy.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Policy.inc');
include('header.inc');
//

include('form_Policy.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Policy.inc');
include('header.inc');
//

include('form_Policy.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Policy.inc');
include('header.inc');
//

include('form_Policy.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Policy.inc');
include('header.inc');
//

include('form_Policy.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Policy.inc');
include('header.inc');
//

include('form_Policy.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Policy.inc');
include('header.inc');
//

include('form_Policy.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Policy.inc');
include('header.inc');
//

include('form_Policy.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Policy.inc');
include('header.inc');
//

include('form_Policy.inc');



include('footer.inc');
?>


