<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Usergroup.inc');
include('header.inc');
//

include('form_Usergroup.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Usergroup.inc');
include('header.inc');
//

include('form_Usergroup.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Usergroup.inc');
include('header.inc');
//

include('form_Usergroup.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Usergroup.inc');
include('header.inc');
//

include('form_Usergroup.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Usergroup.inc');
include('header.inc');
//

include('form_Usergroup.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Usergroup.inc');
include('header.inc');
//

include('form_Usergroup.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Usergroup.inc');
include('header.inc');
//

include('form_Usergroup.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Usergroup.inc');
include('header.inc');
//

include('form_Usergroup.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Usergroup.inc');
include('header.inc');
//

include('form_Usergroup.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Usergroup.inc');
include('header.inc');
//

include('form_Usergroup.inc');



include('footer.inc');
?>


