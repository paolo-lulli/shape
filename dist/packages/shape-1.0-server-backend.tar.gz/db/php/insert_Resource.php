<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Resource.inc');
include('header.inc');
//

include('form_Resource.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Resource.inc');
include('header.inc');
//

include('form_Resource.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Resource.inc');
include('header.inc');
//

include('form_Resource.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Resource.inc');
include('header.inc');
//

include('form_Resource.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Resource.inc');
include('header.inc');
//

include('form_Resource.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Resource.inc');
include('header.inc');
//

include('form_Resource.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Resource.inc');
include('header.inc');
//

include('form_Resource.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Resource.inc');
include('header.inc');
//

include('form_Resource.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Resource.inc');
include('header.inc');
//

include('form_Resource.inc');



include('footer.inc');
?>


<?php
//include('../../auth/web_auth.inc');
include('../../auth/add_Resource.inc');
include('header.inc');
//

include('form_Resource.inc');



include('footer.inc');
?>


