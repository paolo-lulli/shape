#! /usr/bin/perl

our $dbname="webauth.db";
our $dbusername="";
our $dbpassword="";
our $dbtype="SQLite";




1;
