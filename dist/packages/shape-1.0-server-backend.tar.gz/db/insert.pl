#!  /usr/bin/perl

#use lib qw(Usergroup);
use Usergroup;

save_Usergroup('$ID', '$created', '$name', '$updated', '$description');
save_Usergroup("ieria", "iiiiiun titolo di prova");

##################printall_draft();
