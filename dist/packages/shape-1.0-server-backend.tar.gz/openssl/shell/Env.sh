#! /bin/sh

KEYS_DIR=.
PRIVATE_KEY_FILE=$KEYS_DIR/private.pem 
PUBLIC_KEY_FILE=$KEYS_DIR/public.pem 
