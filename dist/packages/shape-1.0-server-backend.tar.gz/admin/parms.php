<?php

echo $argv[1];

?>
