#! /bin/sh

echo 'NAME: '
read NAME
echo 'SURNAME: '
read SURNAME
echo 'NICK: '
read NICK
echo 'PASSWORD: '
read PASSWORD
echo 'EMAIL: '
read EMAIL
