<?php

require('./conf/local.inc');

//require_once(BACKEND_DIR."/kernel/QueryManager.class.inc");

?>
