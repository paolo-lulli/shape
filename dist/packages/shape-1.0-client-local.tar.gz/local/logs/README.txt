This directory may not be used, 
as long as local clients may log
only under the (local) server LOGROOT
