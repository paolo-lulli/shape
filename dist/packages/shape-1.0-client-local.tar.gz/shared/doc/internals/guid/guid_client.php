<?
require_once("GuidGenerator.class.inc");

$gen = new GuidGenerator;

print $gen->generate();
print $gen->generate();
print $gen->generate();
print $gen->generate();
print $gen->generate();
print $gen->generate();
print $gen->generate();
print $gen->generate();

?>
