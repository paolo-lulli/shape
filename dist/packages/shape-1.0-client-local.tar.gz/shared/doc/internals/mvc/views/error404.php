<h1><?php echo $blog_heading; ?></h1>
<p>This is a custom 404 error page.</p>
<p>You can put whatever content you like here such as search for your site</p>
