print localtime("Y-m-d H:i:s");
