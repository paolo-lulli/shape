require('./conf/local.inc');
require_once(BACKEND_DIR."/kernel/QueryBuilder.class.inc");
require('./conf/rpc.inc');
require_once(CLIENT_DIR."/classes/CrudRpcClient.class.inc");
