import hashlib

converted = hashlib.sha1("provadicheche").hexdigest()
print converted
